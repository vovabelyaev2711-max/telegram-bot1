# Laguna Gift Telegram Bot

Telegram-бот эскроу-сервиса **Laguna Gift**.

## Требования

- Python 3.9+
- SQLite (файл БД `dont_touch.db` создаётся автоматически)

## Установка

```bash
pip install -r requirements.txt
```

## Запуск

```bash
python scam.py
```

Бот использует токен, захардкоженный в файле `scam.py` (переменная `bot = TeleBot("<TOKEN>")`).
Перед деплоем на прод замените токен на свой и при необходимости вынесите его в переменные окружения.
